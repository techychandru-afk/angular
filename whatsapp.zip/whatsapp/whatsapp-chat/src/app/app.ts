import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  text?: string;
  image?: string;
  time: string;
  read: boolean;
  privateTo?: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {

  users = [
    { id: 'u1', name: 'Rahul' },
    { id: 'u2', name: 'Priya' },
    { id: 'u3', name: 'Karthik' },
    { id: 'u4', name: 'Anjali' },
    { id: 'u5', name: 'Vikram' }
  ];

  username = '';
  userId = '';
  message = '';
  darkMode = false;

  messages: ChatMessage[] = [];

  emojis = ['😀','😂','😍','😎','🔥','👍','❤️','🎉'];

  channel = new BroadcastChannel('final-navbar-chat');

  constructor() {
    this.channel.onmessage = (event) => {

      const data = event.data;

      if (data.type === 'message') {
        const msg = data.payload;

        if (!msg.privateTo || msg.privateTo === this.userId) {
          msg.read = true;
        }

        this.messages.push(msg);
      }

      if (data.type === 'delete') {
        this.messages = this.messages.filter(m => m.id !== data.id);
      }
    };
  }

  login() {
    const found = this.users.find(u => u.name === this.username);
    if (found) {
      this.userId = found.id;
    } else {
      alert('Use: Rahul, Priya, Karthik, Anjali, Vikram');
    }
  }

  sendMessage(imageData?: string) {

    if (!this.userId) return;
    if (!this.message.trim() && !imageData) return;

    const msg: ChatMessage = {
      id: Math.random().toString(36),
      userId: this.userId,
      username: this.username,
      text: this.message,
      image: imageData,
      time: new Date().toLocaleTimeString(),
      read: false
    };

    this.messages.push(msg);

    this.channel.postMessage({
      type: 'message',
      payload: msg
    });

    this.message = '';
  }

  deleteMessage(id: string) {
    this.messages = this.messages.filter(m => m.id !== id);
    this.channel.postMessage({ type: 'delete', id });
  }

  toggleDark() {
    this.darkMode = !this.darkMode;
  }

  addEmoji(e: string) {
    this.message += e;
  }

  onImage(event: any) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      this.sendMessage(reader.result as string);
    };
    reader.readAsDataURL(file);
  }

  isMe(msg: ChatMessage) {
    return msg.userId === this.userId;
  }

  /* Navbar actions */
  goHome() {
    alert("Home Page");
  }

  videoCall() {
    alert("Starting Video Call...");
  }

  voiceCall() {
    alert("Starting Voice Call...");
  }
}
