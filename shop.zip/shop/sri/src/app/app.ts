import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent {

  customerName = '';
  printType = 'bw';
  pages = 0;

  items: any[] = [];
  grandTotal = 0;

  getRate() {
    return this.printType === 'bw' ? 2 : 5;
  }

  addItem() {
    if (this.pages <= 0) return;

    const rate = this.getRate();
    const total = rate * this.pages;

    this.items.push({
      printType: this.printType === 'bw' ? 'Black & White' : 'Color',
      pages: this.pages,
      rate: rate,
      total: total
    });

    this.calculateGrandTotal();
    this.pages = 0;
  }

  deleteItem(index: number) {
    this.items.splice(index, 1);
    this.calculateGrandTotal();
  }

  calculateGrandTotal() {
    this.grandTotal = this.items.reduce((sum, item) => sum + item.total, 0);
  }

  toggleDarkMode(event: any) {
    if (event.target.checked) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }
}
