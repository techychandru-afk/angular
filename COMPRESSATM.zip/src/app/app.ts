import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Deposit } from "./deposit/deposit";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Deposit],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ATM');

  machine=" this is atm machine";
  work(){
    this.machine ='run suecssfull';
  }
}
