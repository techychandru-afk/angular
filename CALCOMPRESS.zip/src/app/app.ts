import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('rajnideva');
message='click the button';
abcd='vandhuten da';
changemessage()
{
  this.message="you are entered";
}
new(){
this.abcd=" va da mappula";
}
}