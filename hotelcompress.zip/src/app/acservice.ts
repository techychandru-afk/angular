import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AcService {
  
  turnon(){
    return 'ac in ONNNN+++++';
  }
 turnoff(){
    return 'ac in OFFFF---------';
  }
  switchoff(){
    return'ac is switch off......'
  }
}
