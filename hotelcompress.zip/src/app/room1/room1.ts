import { Component } from '@angular/core';
import { AcService } from '../acservice';

@Component({
  selector: 'app-room1',
  imports: [],
  templateUrl: './room1.html',
  styleUrl: './room1.css',
})
export class Room1 {

  message='';
  constructor(private acservice : AcService){
}
  acon(){
this.message=this.acservice.turnon();
  }
  acoff(){
this.message=this.acservice.turnoff();
  }
  switchoff(){
    this.message=this.acservice.switchoff();
  }
}

